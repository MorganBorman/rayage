invalid cpp1333
