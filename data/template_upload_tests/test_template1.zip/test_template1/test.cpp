invalid cpp1222
